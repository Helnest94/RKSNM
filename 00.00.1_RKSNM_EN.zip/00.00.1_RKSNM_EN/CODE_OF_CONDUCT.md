# 🧠 RKSNM Code of Conduct

RKSNM is a public space for sharing ideas, systems, and modular thinking.  
We believe in mutual respect, clarity, and intelligent conversation.

## Expected behavior
- Be respectful and inclusive
- Keep feedback constructive
- Share knowledge freely

## Unacceptable behavior
- Hate speech or discrimination
- Spam or malicious content
- Trolling or personal attacks

By participating, you agree to uphold these principles.

– The RegisX Philosophy Team
