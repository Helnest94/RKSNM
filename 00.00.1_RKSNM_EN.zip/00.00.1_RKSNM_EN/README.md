# 📦 RKSNM Starter Pack (EN)

Welcome to the RKSNM Starter Pack – the Regis-Kajetan Modular Naming System.

This package contains:
- Documentation
- Structural comparisons
- Real examples

Created for humans. Ready for machines.
